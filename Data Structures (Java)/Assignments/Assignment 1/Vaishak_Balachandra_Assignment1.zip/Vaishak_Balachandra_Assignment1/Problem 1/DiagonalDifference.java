public class DiagonalDifference {

    public static int diagonalDifference(int[][] arr) {
        int primaryDiagonal = 0;
        int secondaryDiagonal = 0;
        int n = arr.length;

        for (int i = 0; i < n; i++) {
            primaryDiagonal += arr[i][i];
            secondaryDiagonal += arr[i][n - i - 1];
        }

        return Math.abs(primaryDiagonal - secondaryDiagonal);
    }
}
