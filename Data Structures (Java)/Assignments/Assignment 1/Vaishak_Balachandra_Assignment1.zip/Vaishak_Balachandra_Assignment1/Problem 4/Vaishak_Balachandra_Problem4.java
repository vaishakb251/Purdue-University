import java.util.ArrayList;
import java.util.List;

public class Vaishak_Balachandra_Problem4 {

    // Constructive method to filter and capitalize strings
    public static List<String> filterStringsConstructively(List<String> list, int minLength) {
        List<String> newList = new ArrayList<String>();

        for (String str : list) {
            if (str.length() >= minLength) {
                // Capitalize the first letter of each string
                String capitalized = str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
                newList.add(capitalized);
            }
        }

        return newList;
    }

    public static void main(String[] args) {
        // Create and initialize ArrayList with given elements
        List<String> itemsList = new ArrayList<String>();
        itemsList.add("tomato");
        itemsList.add("cheese");
        itemsList.add("chips");
        itemsList.add("fruit");
        itemsList.add("pie");
        itemsList.add("butter");
        itemsList.add("tea");
        itemsList.add("buns");

        // Print the original list
        System.out.println("Original list: " + itemsList);

        // Filter the list with a minimum length of 4 using the constructive method
        List<String> filteredList = filterStringsConstructively(itemsList, 4);

        // Print the filtered list
        System.out.println("Filtered list: " + filteredList);
    }
}
