import java.util.ArrayList;

public class Vaishak_Balachandra_Problem3 {

    public static void main(String[] args) {
        // Create and initialize ArrayList with given elements
        ArrayList<String> itemsList = new ArrayList<String>();
        itemsList.add("tomato");
        itemsList.add("cheese");
        itemsList.add("chips");
        itemsList.add("Fruit");
        itemsList.add("Pie");
        itemsList.add("butter");
        itemsList.add("tea");
        itemsList.add("buns");

        // Print the original list
        System.out.println("Original list: " + itemsList);

        // Filter the list with a minimum length of 4
        StringFilterArray.filterStrings(itemsList, 4);

        // Print the modified list
        System.out.println("Modified list: " + itemsList);
    }
}
