import java.util.ArrayList;
import java.util.Iterator;

public class StringFilterArray {

    // Method to modify ArrayList destructively
    public static void filterStrings(ArrayList<String> list, int minLength) {
        Iterator<String> iterator = list.iterator();

        while (iterator.hasNext()) {
            String str = iterator.next();
            if (str.length() < minLength) {
                iterator.remove();  // Remove strings shorter than minLength
            }
        }

        // Capitalize the first letter of each remaining string
        for (int i = 0; i < list.size(); i++) {
            String str = list.get(i);
            list.set(i, str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase());
        }
    }
}
