public class FibonacciSum {

    public static int sumEvenFibonacci(int limit) {
        return sumEvenFibonacciHelper(1, 2, limit);
    }

    private static int sumEvenFibonacciHelper(int current, int next, int limit) {
        if (current > limit) {
            return 0;
        }

        int sum = (current % 2 == 0) ? current : 0;
        return sum + sumEvenFibonacciHelper(next, current + next, limit);
    }
}