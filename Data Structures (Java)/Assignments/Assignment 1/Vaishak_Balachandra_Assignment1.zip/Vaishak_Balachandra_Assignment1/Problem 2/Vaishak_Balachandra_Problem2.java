public class Vaishak_Balachandra_Problem2 {

    public static void main(String[] args) {
        int limit = 4000000;
        System.out.println(FibonacciSum.sumEvenFibonacci(limit));
    }
}