# Generated from grammar/MyParser.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .MyParser import MyParser
else:
    from MyParser import MyParser

# This class defines a complete listener for a parse tree produced by MyParser.
class MyParserListener(ParseTreeListener):

    # Enter a parse tree produced by MyParser#program.
    def enterProgram(self, ctx:MyParser.ProgramContext):
        pass

    # Exit a parse tree produced by MyParser#program.
    def exitProgram(self, ctx:MyParser.ProgramContext):
        pass


    # Enter a parse tree produced by MyParser#stmtList.
    def enterStmtList(self, ctx:MyParser.StmtListContext):
        pass

    # Exit a parse tree produced by MyParser#stmtList.
    def exitStmtList(self, ctx:MyParser.StmtListContext):
        pass


    # Enter a parse tree produced by MyParser#stmt.
    def enterStmt(self, ctx:MyParser.StmtContext):
        pass

    # Exit a parse tree produced by MyParser#stmt.
    def exitStmt(self, ctx:MyParser.StmtContext):
        pass


    # Enter a parse tree produced by MyParser#declareStmt.
    def enterDeclareStmt(self, ctx:MyParser.DeclareStmtContext):
        pass

    # Exit a parse tree produced by MyParser#declareStmt.
    def exitDeclareStmt(self, ctx:MyParser.DeclareStmtContext):
        pass


    # Enter a parse tree produced by MyParser#type.
    def enterType(self, ctx:MyParser.TypeContext):
        pass

    # Exit a parse tree produced by MyParser#type.
    def exitType(self, ctx:MyParser.TypeContext):
        pass


    # Enter a parse tree produced by MyParser#idList.
    def enterIdList(self, ctx:MyParser.IdListContext):
        pass

    # Exit a parse tree produced by MyParser#idList.
    def exitIdList(self, ctx:MyParser.IdListContext):
        pass


    # Enter a parse tree produced by MyParser#assignStmt.
    def enterAssignStmt(self, ctx:MyParser.AssignStmtContext):
        pass

    # Exit a parse tree produced by MyParser#assignStmt.
    def exitAssignStmt(self, ctx:MyParser.AssignStmtContext):
        pass


    # Enter a parse tree produced by MyParser#assignOp.
    def enterAssignOp(self, ctx:MyParser.AssignOpContext):
        pass

    # Exit a parse tree produced by MyParser#assignOp.
    def exitAssignOp(self, ctx:MyParser.AssignOpContext):
        pass


    # Enter a parse tree produced by MyParser#functionDefStmt.
    def enterFunctionDefStmt(self, ctx:MyParser.FunctionDefStmtContext):
        pass

    # Exit a parse tree produced by MyParser#functionDefStmt.
    def exitFunctionDefStmt(self, ctx:MyParser.FunctionDefStmtContext):
        pass


    # Enter a parse tree produced by MyParser#functionName.
    def enterFunctionName(self, ctx:MyParser.FunctionNameContext):
        pass

    # Exit a parse tree produced by MyParser#functionName.
    def exitFunctionName(self, ctx:MyParser.FunctionNameContext):
        pass


    # Enter a parse tree produced by MyParser#paramList.
    def enterParamList(self, ctx:MyParser.ParamListContext):
        pass

    # Exit a parse tree produced by MyParser#paramList.
    def exitParamList(self, ctx:MyParser.ParamListContext):
        pass


    # Enter a parse tree produced by MyParser#functionCallStmt.
    def enterFunctionCallStmt(self, ctx:MyParser.FunctionCallStmtContext):
        pass

    # Exit a parse tree produced by MyParser#functionCallStmt.
    def exitFunctionCallStmt(self, ctx:MyParser.FunctionCallStmtContext):
        pass


    # Enter a parse tree produced by MyParser#functionCall.
    def enterFunctionCall(self, ctx:MyParser.FunctionCallContext):
        pass

    # Exit a parse tree produced by MyParser#functionCall.
    def exitFunctionCall(self, ctx:MyParser.FunctionCallContext):
        pass


    # Enter a parse tree produced by MyParser#argList.
    def enterArgList(self, ctx:MyParser.ArgListContext):
        pass

    # Exit a parse tree produced by MyParser#argList.
    def exitArgList(self, ctx:MyParser.ArgListContext):
        pass


    # Enter a parse tree produced by MyParser#expression.
    def enterExpression(self, ctx:MyParser.ExpressionContext):
        pass

    # Exit a parse tree produced by MyParser#expression.
    def exitExpression(self, ctx:MyParser.ExpressionContext):
        pass


    # Enter a parse tree produced by MyParser#ifExpression.
    def enterIfExpression(self, ctx:MyParser.IfExpressionContext):
        pass

    # Exit a parse tree produced by MyParser#ifExpression.
    def exitIfExpression(self, ctx:MyParser.IfExpressionContext):
        pass


    # Enter a parse tree produced by MyParser#boolExpr.
    def enterBoolExpr(self, ctx:MyParser.BoolExprContext):
        pass

    # Exit a parse tree produced by MyParser#boolExpr.
    def exitBoolExpr(self, ctx:MyParser.BoolExprContext):
        pass


    # Enter a parse tree produced by MyParser#boolTerm.
    def enterBoolTerm(self, ctx:MyParser.BoolTermContext):
        pass

    # Exit a parse tree produced by MyParser#boolTerm.
    def exitBoolTerm(self, ctx:MyParser.BoolTermContext):
        pass


    # Enter a parse tree produced by MyParser#boolFactor.
    def enterBoolFactor(self, ctx:MyParser.BoolFactorContext):
        pass

    # Exit a parse tree produced by MyParser#boolFactor.
    def exitBoolFactor(self, ctx:MyParser.BoolFactorContext):
        pass


    # Enter a parse tree produced by MyParser#boolLiteral.
    def enterBoolLiteral(self, ctx:MyParser.BoolLiteralContext):
        pass

    # Exit a parse tree produced by MyParser#boolLiteral.
    def exitBoolLiteral(self, ctx:MyParser.BoolLiteralContext):
        pass


    # Enter a parse tree produced by MyParser#comparison.
    def enterComparison(self, ctx:MyParser.ComparisonContext):
        pass

    # Exit a parse tree produced by MyParser#comparison.
    def exitComparison(self, ctx:MyParser.ComparisonContext):
        pass


    # Enter a parse tree produced by MyParser#compOp.
    def enterCompOp(self, ctx:MyParser.CompOpContext):
        pass

    # Exit a parse tree produced by MyParser#compOp.
    def exitCompOp(self, ctx:MyParser.CompOpContext):
        pass


    # Enter a parse tree produced by MyParser#arithmeticExpr.
    def enterArithmeticExpr(self, ctx:MyParser.ArithmeticExprContext):
        pass

    # Exit a parse tree produced by MyParser#arithmeticExpr.
    def exitArithmeticExpr(self, ctx:MyParser.ArithmeticExprContext):
        pass


    # Enter a parse tree produced by MyParser#term.
    def enterTerm(self, ctx:MyParser.TermContext):
        pass

    # Exit a parse tree produced by MyParser#term.
    def exitTerm(self, ctx:MyParser.TermContext):
        pass


    # Enter a parse tree produced by MyParser#value.
    def enterValue(self, ctx:MyParser.ValueContext):
        pass

    # Exit a parse tree produced by MyParser#value.
    def exitValue(self, ctx:MyParser.ValueContext):
        pass


    # Enter a parse tree produced by MyParser#factor.
    def enterFactor(self, ctx:MyParser.FactorContext):
        pass

    # Exit a parse tree produced by MyParser#factor.
    def exitFactor(self, ctx:MyParser.FactorContext):
        pass



del MyParser