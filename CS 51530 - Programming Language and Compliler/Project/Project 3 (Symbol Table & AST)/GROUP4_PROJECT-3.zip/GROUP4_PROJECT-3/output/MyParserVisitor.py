# Generated from grammar/MyParser.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .MyParser import MyParser
else:
    from MyParser import MyParser

# This class defines a complete generic visitor for a parse tree produced by MyParser.

class MyParserVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by MyParser#program.
    def visitProgram(self, ctx:MyParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#stmtList.
    def visitStmtList(self, ctx:MyParser.StmtListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#stmt.
    def visitStmt(self, ctx:MyParser.StmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#declareStmt.
    def visitDeclareStmt(self, ctx:MyParser.DeclareStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#type.
    def visitType(self, ctx:MyParser.TypeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#idList.
    def visitIdList(self, ctx:MyParser.IdListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#assignStmt.
    def visitAssignStmt(self, ctx:MyParser.AssignStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#assignOp.
    def visitAssignOp(self, ctx:MyParser.AssignOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#functionDefStmt.
    def visitFunctionDefStmt(self, ctx:MyParser.FunctionDefStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#functionName.
    def visitFunctionName(self, ctx:MyParser.FunctionNameContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#paramList.
    def visitParamList(self, ctx:MyParser.ParamListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#functionCallStmt.
    def visitFunctionCallStmt(self, ctx:MyParser.FunctionCallStmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#functionCall.
    def visitFunctionCall(self, ctx:MyParser.FunctionCallContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#argList.
    def visitArgList(self, ctx:MyParser.ArgListContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#expression.
    def visitExpression(self, ctx:MyParser.ExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#ifExpression.
    def visitIfExpression(self, ctx:MyParser.IfExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#boolExpr.
    def visitBoolExpr(self, ctx:MyParser.BoolExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#boolTerm.
    def visitBoolTerm(self, ctx:MyParser.BoolTermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#boolFactor.
    def visitBoolFactor(self, ctx:MyParser.BoolFactorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#boolLiteral.
    def visitBoolLiteral(self, ctx:MyParser.BoolLiteralContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#comparison.
    def visitComparison(self, ctx:MyParser.ComparisonContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#compOp.
    def visitCompOp(self, ctx:MyParser.CompOpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#arithmeticExpr.
    def visitArithmeticExpr(self, ctx:MyParser.ArithmeticExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#term.
    def visitTerm(self, ctx:MyParser.TermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#value.
    def visitValue(self, ctx:MyParser.ValueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by MyParser#factor.
    def visitFactor(self, ctx:MyParser.FactorContext):
        return self.visitChildren(ctx)



del MyParser