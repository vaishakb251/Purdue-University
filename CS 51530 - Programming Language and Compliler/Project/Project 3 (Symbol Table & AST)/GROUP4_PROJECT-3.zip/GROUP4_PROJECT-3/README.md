# CS51530 Project 3: Symbol Table Generation and AST Construction

This project is the third phase of a custom compiler. It implements:
- Symbol Table generation with scope and memory offset tracking
- Abstract Syntax Tree (AST) construction from a parse tree
- Function definition/lookup support
- Visual AST export using Graphviz

---

## Project Structure

```
compiler-project/
├── grammar/                # ANTLR grammar files
│   ├── MyLexer.g4
│   └── MyParser.g4
├── input/                  # Sample test programs
│   ├── example_valid_1.txt
│   ├── example_invalid_1.txt
│   └── ...
├── output/                 # ANTLR generated files (MyLexer.py, MyParser.py, etc.)
├── src/                    # Source code
│   ├── test_parser.py      # Main entry point
│   ├── custom_visitor.py   # AST + symbol table logic
│   ├── symbol_table_ast.py # Data structures for AST + tables
│   └── test_lexer.py       # Lexer tester (Phase 1)
├── ast_output.png          # Latest AST visual
├── parse_tree.dot          # Graphviz format of the AST
```

---

## How to Run

### Step 1: Install Requirements

```
pip install antlr4-python3-runtime
```

Make sure [Graphviz](https://graphviz.org/download/) is installed and added to your system `PATH`.


### Step 2: Run the Compiler

To parse an input file and generate AST:

```
python src/test_parser.py input/example_valid_1.txt
```

This will output:
- The AST (in console)
- The symbol table
- `parse_tree.dot` file
- `ast_output.png` image from Graphviz

---

### Optional: Run Lexer Only (Phase 1)

```
python src/test_lexer.py input/sample_input.txt
```

---

## Test Inputs

| File                   | Description                          |
|------------------------|--------------------------------------|
| `example_valid_1.txt`  | Uses block scope and arithmetic      |
| `example_valid_2.txt`  | Function + char + if expressions     |
| `example_invalid_1.txt`| Undeclared variable error            |
| `example_invalid_2.txt`| Type mismatch assignment             |

---

## Author

Course: CS51530
Project 3: Compiler Phase – Symbol Table & AST