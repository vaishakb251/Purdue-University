# src/custom_visitor.py

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../output')))

from MyParserVisitor import MyParserVisitor
from MyParser import MyParser
from symbol_table_ast import SymbolTable, ASTNode

class CustomVisitor(MyParserVisitor):
    def __init__(self):
        self.global_scope = SymbolTable()
        self.current_scope = self.global_scope
        self.ast_root = ASTNode("Program")

    def visitProgram(self, ctx: MyParser.ProgramContext):
        for stmt in ctx.stmtList().stmt():
            node = self.visit(stmt)
            self.ast_root.add_child(node)
        return self.ast_root

    def visitStmt(self, ctx: MyParser.StmtContext):
        if ctx.LBRACE():
            print("\n🔹 Entering new scope")
            new_scope = SymbolTable(parent=self.current_scope)
            self.current_scope = new_scope

            stmt_list_node = self.visit(ctx.stmtList())

            print("🔹 Scope symbol table:")
            print(self.current_scope)
            print("🔹 Exiting scope\n")

            self.current_scope = self.current_scope.parent
            return stmt_list_node
        else:
            return self.visitChildren(ctx)

    def visitStmtList(self, ctx: MyParser.StmtListContext):
        block_node = ASTNode("Block")
        for stmt in ctx.stmt():
            node = self.visit(stmt)
            block_node.add_child(node)
        return block_node

    def visitDeclareStmt(self, ctx: MyParser.DeclareStmtContext):
        var_type = ctx.type_().getText()
        var_names = [id_.getText() for id_ in ctx.idList().IDENTIFIER()]
        decl_node = ASTNode("DeclareStmt", var_type)

        for name in var_names:
            try:
                self.current_scope.define(name, var_type)
                decl_node.add_child(ASTNode("Identifier", name))
            except Exception as e:
                print(e)

        return decl_node

    def visitAssignStmt(self, ctx: MyParser.AssignStmtContext):
        var_name = ctx.IDENTIFIER().getText()
        try:
            symbol = self.current_scope.lookup(var_name)
        except Exception as e:
            print(e)
            return ASTNode("InvalidAssignment", var_name)

        expr_node = self.visit(ctx.expression())
        expr_type = expr_node.value if isinstance(expr_node, ASTNode) else "unknown"

        if symbol.type != expr_type and expr_type != "unknown":
            print(f"Type Mismatch: cannot assign {expr_type} to {symbol.type} variable '{var_name}'")

        assign_node = ASTNode("Assignment", f"{var_name} =")
        assign_node.add_child(expr_node)
        return assign_node

    def visitExpression(self, ctx: MyParser.ExpressionContext):
        if ctx.ifExpression():
            return self.visit(ctx.ifExpression())
        elif ctx.boolExpr():
            return self.visit(ctx.boolExpr())
        elif ctx.arithmeticExpr():
            return self.visit(ctx.arithmeticExpr())
        elif ctx.functionCall():
            return self.visit(ctx.functionCall())
        else:
            return ASTNode("Expression", "unknown")

    def visitArithmeticExpr(self, ctx: MyParser.ArithmeticExprContext):
        if len(ctx.term()) == 1:
            return self.visit(ctx.term(0))

        left_node = self.visit(ctx.term(0))
        right_node = self.visit(ctx.term(1))
        operator = ctx.getChild(1).getText()

        left_type = left_node.value
        right_type = right_node.value
        if left_type != right_type:
            print(f"Type Mismatch in arithmetic expression: {left_type} {operator} {right_type}")
            result_type = "unknown"
        else:
            result_type = left_type

        node = ASTNode("ArithmeticExpr", operator)
        node.add_child(left_node)
        node.add_child(right_node)
        node.value = result_type
        return node

    def visitTerm(self, ctx: MyParser.TermContext):
        if len(ctx.value()) == 1:
            return self.visit(ctx.value(0))

        left_node = self.visit(ctx.value(0))
        right_node = self.visit(ctx.value(1))
        operator = ctx.getChild(1).getText()

        left_type = left_node.value
        right_type = right_node.value
        if left_type != right_type:
            print(f"Type Mismatch in term: {left_type} {operator} {right_type}")
            result_type = "unknown"
        else:
            result_type = left_type

        node = ASTNode("Term", operator)
        node.add_child(left_node)
        node.add_child(right_node)
        node.value = result_type
        return node

    def visitValue(self, ctx: MyParser.ValueContext):
        return self.visit(ctx.factor())

    def visitFactor(self, ctx: MyParser.FactorContext):
        if ctx.INTEGER_LITERAL():
            return ASTNode("IntLiteral", "int")
        elif ctx.DOUBLE_LITERAL():
            return ASTNode("DoubleLiteral", "double")
        elif ctx.IDENTIFIER():
            name = ctx.IDENTIFIER().getText()
            try:
                symbol = self.current_scope.lookup(name)
                return ASTNode("Identifier", symbol.type)
            except Exception as e:
                print(e)
                return ASTNode("UnknownIdentifier", name)
        elif ctx.CHAR_LITERAL():
            return ASTNode("CharLiteral", "char")
        elif ctx.LPAREN():
            return self.visit(ctx.arithmeticExpr())
        else:
            return ASTNode("Factor", "unknown")

    def visitIfExpression(self, ctx: MyParser.IfExpressionContext):
        condition_node = self.visit(ctx.boolExpr())
        then_node = self.visit(ctx.expression(0))
        else_node = self.visit(ctx.expression(1))

        then_type = then_node.value
        else_type = else_node.value
        if then_type != else_type:
            print(f"Type Mismatch in 'if' expression: then={then_type}, else={else_type}")

        if_expr_node = ASTNode("IfExpression")
        if_expr_node.add_child(ASTNode("Condition", condition_node.value))
        if_expr_node.add_child(ASTNode("Then", then_type))
        if_expr_node.add_child(ASTNode("Else", else_type))

        if_expr_node.value = then_type if then_type == else_type else "unknown"
        return if_expr_node

    def visitBoolExpr(self, ctx: MyParser.BoolExprContext):
        return ASTNode("BoolExpr", "bool")

    def visitFunctionDefStmt(self, ctx: MyParser.FunctionDefStmtContext):
        name = ctx.functionName().getText()
        expr_node = self.visit(ctx.expression())

        param_types = []
        if ctx.paramList():
            children = ctx.paramList().children
            for i in range(0, len(children), 3):  # type IDENTIFIER COMMA
                if i + 1 < len(children):
                    param_type = children[i].getText()
                    param_types.append(param_type)

        try:
            self.current_scope.define_function(name, param_types, expr_node.value)
        except Exception as e:
            print(e)

        func_node = ASTNode("FunctionDef", name)
        for ptype in param_types:
            func_node.add_child(ASTNode("Param", ptype))
        func_node.add_child(expr_node)
        return func_node

    def visitFunctionCall(self, ctx: MyParser.FunctionCallContext):
        name = ctx.functionName().getText()
        args = ctx.argList().expression() if ctx.argList() else []
        arg_nodes = [self.visit(arg) for arg in args]
        arg_types = [n.value for n in arg_nodes]

        try:
            signature = self.current_scope.lookup_function(name)
            expected = signature["params"]

            if len(expected) != len(arg_types):
                print(f"Function call to '{name}' has wrong number of arguments: expected {len(expected)}, got {len(arg_types)}")
            else:
                for i, (e, a) in enumerate(zip(expected, arg_types)):
                    if e != a:
                        print(f"Argument {i+1} type mismatch in call to '{name}': expected {e}, got {a}")
        except Exception as e:
            print(e)

        call_node = ASTNode("FunctionCall", name)
        for arg in arg_nodes:
            call_node.add_child(arg)
        call_node.value = signature["return"] if 'return' in signature else "unknown"
        return call_node
