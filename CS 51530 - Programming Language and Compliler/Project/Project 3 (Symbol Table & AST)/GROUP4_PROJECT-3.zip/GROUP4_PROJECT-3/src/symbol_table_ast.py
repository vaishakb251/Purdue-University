# SYMBOL TABLE IMPLEMENTATION

class Symbol:
    def __init__(self, name, type_, offset):
        self.name = name
        self.type = type_
        self.offset = offset

    def __repr__(self):
        return f"{self.name}: {self.type} (offset={self.offset})"

class SymbolTable:
    def __init__(self, parent=None):
        self.symbols = {}
        self.functions = {}  #Store functions separately
        self.parent = parent
        self.offset = 0

    def define(self, name, type_):
        if name in self.symbols:
            raise Exception(f"Duplicate declaration of variable '{name}'")
        size = 4 if type_ == 'int' else 8 if type_ == 'double' else 1
        self.symbols[name] = Symbol(name, type_, self.offset)
        self.offset += size

    def lookup(self, name):
        if name in self.symbols:
            return self.symbols[name]
        elif self.parent:
            return self.parent.lookup(name)
        else:
            raise Exception(f"Variable '{name}' not declared")

    # Function handling
    def define_function(self, name, param_types, return_type):
        if name in self.functions:
            raise Exception(f"Function '{name}' already defined.")
        self.functions[name] = {
            "params": param_types,
            "return": return_type
        }

    def lookup_function(self, name):
        if name in self.functions:
            return self.functions[name]
        elif self.parent:
            return self.parent.lookup_function(name)
        else:
            raise Exception(f"Function '{name}' is not defined.")

    def __repr__(self):
        table = "\n".join([str(sym) for sym in self.symbols.values()])
        return f"SymbolTable:\n{table}"

# ABSTRACT SYNTAX TREE IMPLEMENTATION

class ASTNode:
    def __init__(self, node_type, value=None):
        self.node_type = node_type
        self.value = value
        self.children = []

    def add_child(self, child):
        if child is not None:
            self.children.append(child)

    def __repr__(self, level=0):
        indent = "\t" * level
        result = f"{indent}{self.node_type}: {self.value}\n"
        for child in self.children:
            result += child.__repr__(level + 1) if isinstance(child, ASTNode) else f"{indent}\t{child}\n"
        return result

def export_ast_to_dot(root: ASTNode, filename="ast_output.dot"):
    with open(filename, 'w') as f:
        f.write("digraph AST {\n")
        node_id = [0]

        def write_node(node, parent_id=None):
            curr_id = node_id[0]
            label = f"{node.node_type}: {node.value}" if node.value else node.node_type
            f.write(f'    node{curr_id} [label="{label}"];\n')

            if parent_id is not None:
                f.write(f'    node{parent_id} -> node{curr_id};\n')

            node_id[0] += 1
            for child in node.children:
                if isinstance(child, ASTNode):
                    write_node(child, curr_id)

        write_node(root)
        f.write("}\n")
