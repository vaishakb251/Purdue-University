import sys
import os
from antlr4 import *
from antlr4.error.ErrorListener import ErrorListener
import subprocess  #Required for generating PNG

# Add the 'output/' and 'src/' directories to the Python module path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../output')))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), './')))

# Import the lexer, parser, custom visitor, and export utility
from MyLexer import MyLexer
from MyParser import MyParser
from custom_visitor import CustomVisitor
from symbol_table_ast import export_ast_to_dot  #Make sure this is implemented

# Custom error listener
class CustomErrorListener(ErrorListener):
    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        print(f"Syntax Error at line {line}, column {column}: {msg}")
        sys.exit(1)

def main():
    if len(sys.argv) < 2:
        print("Usage: python src/test_parser.py <input_file>")
        sys.exit(1)

    input_file = sys.argv[1]
    input_stream = FileStream(input_file, encoding='utf-8')

    lexer = MyLexer(input_stream)
    token_stream = CommonTokenStream(lexer)
    parser = MyParser(token_stream)

    parser.removeErrorListeners()
    parser.addErrorListener(CustomErrorListener())

    tree = parser.program()
    visitor = CustomVisitor()
    ast = visitor.visit(tree)

    print("\n Abstract Syntax Tree (AST):\n")
    print(ast)

    print("\n Final Symbol Table:\n")
    print(visitor.global_scope)

    #Export AST to .dot and .png
    export_ast_to_dot(ast, "parse_tree.dot")
    print("AST exported to parse_tree.dot")

    try:
        subprocess.run(["dot", "-Tpng", "parse_tree.dot", "-o", "ast_output.png"], check=True)
        print("AST image generated: ast_output.png")
    except FileNotFoundError:
        print("Graphviz 'dot' command not found. Please install Graphviz and add it to PATH.")

if __name__ == "__main__":
    main()
