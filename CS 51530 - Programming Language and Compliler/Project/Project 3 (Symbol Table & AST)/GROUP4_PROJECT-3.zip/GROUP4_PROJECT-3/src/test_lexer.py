import sys
import os
from antlr4 import FileStream, CommonTokenStream

#Add the output directory to Python path directly
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../output')))

from MyLexer import MyLexer  #Now importing directly from output/

# Ensure a filename is provided
if len(sys.argv) < 2:
    print("Usage: python test_lexer.py <input_file>")
    sys.exit(1)

# Read the specified input file
input_filename = sys.argv[1]
input_stream = FileStream(input_filename, encoding="utf-8")

# Initialize lexer and token stream
lexer = MyLexer(input_stream)
token_stream = CommonTokenStream(lexer)
token_stream.fill()

# Define invalid token categories based on lexer rules
INVALID_TOKENS = {
    "INVALID_INTEGER_LITERAL", 
    "INVALID_DOUBLE_LITERAL", 
    "INVALID_IDENTIFIER", 
    "ERROR"
}

# Output tokens
output_filename = input_filename.replace('.txt', '_output.txt')
with open(output_filename, 'w') as output_file:
    for token in token_stream.tokens:
        if token.type == -1:  # EOF token
            break

        token_text = token.text
        token_category = lexer.symbolicNames[token.type] if token.type > 0 else "UNKNOWN"
        validity = "INVALID" if token_category in INVALID_TOKENS else "VALID"
        output_line = f"<{token_text}, {token_category}> --- {validity}"
        print(output_line)
        # output_file.write(output_line + '\n')
