# Generated from grammar/MyParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,44,210,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,1,0,1,0,1,
        1,5,1,56,8,1,10,1,12,1,59,9,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,
        2,69,8,2,1,3,1,3,1,3,1,3,1,4,1,4,1,5,1,5,1,5,5,5,80,8,5,10,5,12,
        5,83,9,5,1,6,1,6,1,6,1,6,1,6,1,7,1,7,1,8,1,8,1,8,1,8,3,8,96,8,8,
        1,8,1,8,1,8,1,8,1,8,1,9,1,9,1,10,1,10,1,10,1,10,1,10,1,10,5,10,111,
        8,10,10,10,12,10,114,9,10,1,11,1,11,1,11,1,12,1,12,1,12,3,12,122,
        8,12,1,12,1,12,1,13,1,13,1,13,5,13,129,8,13,10,13,12,13,132,9,13,
        1,14,1,14,1,14,1,14,3,14,138,8,14,1,15,1,15,1,15,1,15,1,15,1,15,
        1,15,1,16,1,16,1,16,5,16,150,8,16,10,16,12,16,153,9,16,1,17,1,17,
        1,17,5,17,158,8,17,10,17,12,17,161,9,17,1,18,1,18,1,18,1,18,1,18,
        1,18,3,18,169,8,18,1,19,1,19,1,20,1,20,1,20,1,20,1,21,1,21,1,22,
        1,22,1,22,5,22,182,8,22,10,22,12,22,185,9,22,1,23,1,23,1,23,5,23,
        190,8,23,10,23,12,23,193,9,23,1,24,1,24,1,24,3,24,198,8,24,1,25,
        1,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,208,8,25,1,25,0,0,26,0,2,
        4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,
        50,0,6,1,0,1,5,1,0,14,18,1,0,10,11,1,0,24,26,1,0,19,20,1,0,21,22,
        207,0,52,1,0,0,0,2,57,1,0,0,0,4,68,1,0,0,0,6,70,1,0,0,0,8,74,1,0,
        0,0,10,76,1,0,0,0,12,84,1,0,0,0,14,89,1,0,0,0,16,91,1,0,0,0,18,102,
        1,0,0,0,20,104,1,0,0,0,22,115,1,0,0,0,24,118,1,0,0,0,26,125,1,0,
        0,0,28,137,1,0,0,0,30,139,1,0,0,0,32,146,1,0,0,0,34,154,1,0,0,0,
        36,168,1,0,0,0,38,170,1,0,0,0,40,172,1,0,0,0,42,176,1,0,0,0,44,178,
        1,0,0,0,46,186,1,0,0,0,48,197,1,0,0,0,50,207,1,0,0,0,52,53,3,2,1,
        0,53,1,1,0,0,0,54,56,3,4,2,0,55,54,1,0,0,0,56,59,1,0,0,0,57,55,1,
        0,0,0,57,58,1,0,0,0,58,3,1,0,0,0,59,57,1,0,0,0,60,69,3,6,3,0,61,
        69,3,12,6,0,62,69,3,16,8,0,63,69,3,22,11,0,64,65,5,33,0,0,65,66,
        3,2,1,0,66,67,5,34,0,0,67,69,1,0,0,0,68,60,1,0,0,0,68,61,1,0,0,0,
        68,62,1,0,0,0,68,63,1,0,0,0,68,64,1,0,0,0,69,5,1,0,0,0,70,71,3,8,
        4,0,71,72,3,10,5,0,72,73,5,29,0,0,73,7,1,0,0,0,74,75,7,0,0,0,75,
        9,1,0,0,0,76,81,5,40,0,0,77,78,5,30,0,0,78,80,5,40,0,0,79,77,1,0,
        0,0,80,83,1,0,0,0,81,79,1,0,0,0,81,82,1,0,0,0,82,11,1,0,0,0,83,81,
        1,0,0,0,84,85,5,40,0,0,85,86,3,14,7,0,86,87,3,28,14,0,87,88,5,29,
        0,0,88,13,1,0,0,0,89,90,7,1,0,0,90,15,1,0,0,0,91,92,5,6,0,0,92,93,
        3,18,9,0,93,95,5,31,0,0,94,96,3,20,10,0,95,94,1,0,0,0,95,96,1,0,
        0,0,96,97,1,0,0,0,97,98,5,32,0,0,98,99,5,14,0,0,99,100,3,28,14,0,
        100,101,5,29,0,0,101,17,1,0,0,0,102,103,5,40,0,0,103,19,1,0,0,0,
        104,105,3,8,4,0,105,112,5,40,0,0,106,107,5,30,0,0,107,108,3,8,4,
        0,108,109,5,40,0,0,109,111,1,0,0,0,110,106,1,0,0,0,111,114,1,0,0,
        0,112,110,1,0,0,0,112,113,1,0,0,0,113,21,1,0,0,0,114,112,1,0,0,0,
        115,116,3,24,12,0,116,117,5,29,0,0,117,23,1,0,0,0,118,119,3,18,9,
        0,119,121,5,31,0,0,120,122,3,26,13,0,121,120,1,0,0,0,121,122,1,0,
        0,0,122,123,1,0,0,0,123,124,5,32,0,0,124,25,1,0,0,0,125,130,3,28,
        14,0,126,127,5,30,0,0,127,129,3,28,14,0,128,126,1,0,0,0,129,132,
        1,0,0,0,130,128,1,0,0,0,130,131,1,0,0,0,131,27,1,0,0,0,132,130,1,
        0,0,0,133,138,3,30,15,0,134,138,3,32,16,0,135,138,3,44,22,0,136,
        138,3,24,12,0,137,133,1,0,0,0,137,134,1,0,0,0,137,135,1,0,0,0,137,
        136,1,0,0,0,138,29,1,0,0,0,139,140,5,7,0,0,140,141,3,32,16,0,141,
        142,5,8,0,0,142,143,3,28,14,0,143,144,5,9,0,0,144,145,3,28,14,0,
        145,31,1,0,0,0,146,151,3,34,17,0,147,148,5,12,0,0,148,150,3,34,17,
        0,149,147,1,0,0,0,150,153,1,0,0,0,151,149,1,0,0,0,151,152,1,0,0,
        0,152,33,1,0,0,0,153,151,1,0,0,0,154,159,3,36,18,0,155,156,5,13,
        0,0,156,158,3,36,18,0,157,155,1,0,0,0,158,161,1,0,0,0,159,157,1,
        0,0,0,159,160,1,0,0,0,160,35,1,0,0,0,161,159,1,0,0,0,162,169,3,38,
        19,0,163,164,5,31,0,0,164,165,3,32,16,0,165,166,5,32,0,0,166,169,
        1,0,0,0,167,169,3,40,20,0,168,162,1,0,0,0,168,163,1,0,0,0,168,167,
        1,0,0,0,169,37,1,0,0,0,170,171,7,2,0,0,171,39,1,0,0,0,172,173,3,
        44,22,0,173,174,3,42,21,0,174,175,3,44,22,0,175,41,1,0,0,0,176,177,
        7,3,0,0,177,43,1,0,0,0,178,183,3,46,23,0,179,180,7,4,0,0,180,182,
        3,46,23,0,181,179,1,0,0,0,182,185,1,0,0,0,183,181,1,0,0,0,183,184,
        1,0,0,0,184,45,1,0,0,0,185,183,1,0,0,0,186,191,3,48,24,0,187,188,
        7,5,0,0,188,190,3,48,24,0,189,187,1,0,0,0,190,193,1,0,0,0,191,189,
        1,0,0,0,191,192,1,0,0,0,192,47,1,0,0,0,193,191,1,0,0,0,194,195,5,
        20,0,0,195,198,3,50,25,0,196,198,3,50,25,0,197,194,1,0,0,0,197,196,
        1,0,0,0,198,49,1,0,0,0,199,200,5,31,0,0,200,201,3,44,22,0,201,202,
        5,32,0,0,202,208,1,0,0,0,203,208,5,40,0,0,204,208,5,35,0,0,205,208,
        5,39,0,0,206,208,5,36,0,0,207,199,1,0,0,0,207,203,1,0,0,0,207,204,
        1,0,0,0,207,205,1,0,0,0,207,206,1,0,0,0,208,51,1,0,0,0,15,57,68,
        81,95,112,121,130,137,151,159,168,183,191,197,207
    ]

class MyParser ( Parser ):

    grammarFileName = "MyParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'double'", "'int'", "'long'", "'char'", 
                     "'bool'", "'fun'", "'if'", "'then'", "'else'", "'true'", 
                     "'false'", "'orelse'", "'andalso'", "'='", "'+='", 
                     "'-='", "'*='", "'/='", "'+'", "'-'", "'*'", "'/'", 
                     "'//'", "'>'", "'<'", "'=='", "'!='", "'!'", "';'", 
                     "','", "'('", "')'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "KEYWORD_DOUBLE", "KEYWORD_INT", "KEYWORD_LONG", 
                      "KEYWORD_CHAR", "KEYWORD_BOOL", "KEYWORD_FUN", "KEYWORD_IF", 
                      "KEYWORD_THEN", "KEYWORD_ELSE", "KEYWORD_TRUE", "KEYWORD_FALSE", 
                      "KEYWORD_ORELSE", "KEYWORD_ANDALSO", "ASSIGN", "PLUS_ASSIGN", 
                      "MINUS_ASSIGN", "MULT_ASSIGN", "DIV_ASSIGN", "PLUS", 
                      "MINUS", "MULT", "DIV", "INT_DIV", "GT", "LT", "EQ", 
                      "NEQ", "NOT", "SEMICOLON", "COMMA", "LPAREN", "RPAREN", 
                      "LBRACE", "RBRACE", "INTEGER_LITERAL", "DOUBLE_LITERAL", 
                      "INVALID_INTEGER_LITERAL", "INVALID_DOUBLE_LITERAL", 
                      "CHAR_LITERAL", "IDENTIFIER", "INVALID_IDENTIFIER", 
                      "COMMENT", "WS", "ERROR" ]

    RULE_program = 0
    RULE_stmtList = 1
    RULE_stmt = 2
    RULE_declareStmt = 3
    RULE_type = 4
    RULE_idList = 5
    RULE_assignStmt = 6
    RULE_assignOp = 7
    RULE_functionDefStmt = 8
    RULE_functionName = 9
    RULE_paramList = 10
    RULE_functionCallStmt = 11
    RULE_functionCall = 12
    RULE_argList = 13
    RULE_expression = 14
    RULE_ifExpression = 15
    RULE_boolExpr = 16
    RULE_boolTerm = 17
    RULE_boolFactor = 18
    RULE_boolLiteral = 19
    RULE_comparison = 20
    RULE_compOp = 21
    RULE_arithmeticExpr = 22
    RULE_term = 23
    RULE_value = 24
    RULE_factor = 25

    ruleNames =  [ "program", "stmtList", "stmt", "declareStmt", "type", 
                   "idList", "assignStmt", "assignOp", "functionDefStmt", 
                   "functionName", "paramList", "functionCallStmt", "functionCall", 
                   "argList", "expression", "ifExpression", "boolExpr", 
                   "boolTerm", "boolFactor", "boolLiteral", "comparison", 
                   "compOp", "arithmeticExpr", "term", "value", "factor" ]

    EOF = Token.EOF
    KEYWORD_DOUBLE=1
    KEYWORD_INT=2
    KEYWORD_LONG=3
    KEYWORD_CHAR=4
    KEYWORD_BOOL=5
    KEYWORD_FUN=6
    KEYWORD_IF=7
    KEYWORD_THEN=8
    KEYWORD_ELSE=9
    KEYWORD_TRUE=10
    KEYWORD_FALSE=11
    KEYWORD_ORELSE=12
    KEYWORD_ANDALSO=13
    ASSIGN=14
    PLUS_ASSIGN=15
    MINUS_ASSIGN=16
    MULT_ASSIGN=17
    DIV_ASSIGN=18
    PLUS=19
    MINUS=20
    MULT=21
    DIV=22
    INT_DIV=23
    GT=24
    LT=25
    EQ=26
    NEQ=27
    NOT=28
    SEMICOLON=29
    COMMA=30
    LPAREN=31
    RPAREN=32
    LBRACE=33
    RBRACE=34
    INTEGER_LITERAL=35
    DOUBLE_LITERAL=36
    INVALID_INTEGER_LITERAL=37
    INVALID_DOUBLE_LITERAL=38
    CHAR_LITERAL=39
    IDENTIFIER=40
    INVALID_IDENTIFIER=41
    COMMENT=42
    WS=43
    ERROR=44

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmtList(self):
            return self.getTypedRuleContext(MyParser.StmtListContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):

        localctx = MyParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self.stmtList()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.StmtContext)
            else:
                return self.getTypedRuleContext(MyParser.StmtContext,i)


        def getRuleIndex(self):
            return MyParser.RULE_stmtList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmtList" ):
                listener.enterStmtList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmtList" ):
                listener.exitStmtList(self)




    def stmtList(self):

        localctx = MyParser.StmtListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stmtList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 1108101562494) != 0):
                self.state = 54
                self.stmt()
                self.state = 59
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declareStmt(self):
            return self.getTypedRuleContext(MyParser.DeclareStmtContext,0)


        def assignStmt(self):
            return self.getTypedRuleContext(MyParser.AssignStmtContext,0)


        def functionDefStmt(self):
            return self.getTypedRuleContext(MyParser.FunctionDefStmtContext,0)


        def functionCallStmt(self):
            return self.getTypedRuleContext(MyParser.FunctionCallStmtContext,0)


        def LBRACE(self):
            return self.getToken(MyParser.LBRACE, 0)

        def stmtList(self):
            return self.getTypedRuleContext(MyParser.StmtListContext,0)


        def RBRACE(self):
            return self.getToken(MyParser.RBRACE, 0)

        def getRuleIndex(self):
            return MyParser.RULE_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt" ):
                listener.enterStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt" ):
                listener.exitStmt(self)




    def stmt(self):

        localctx = MyParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_stmt)
        try:
            self.state = 68
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 60
                self.declareStmt()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 61
                self.assignStmt()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 62
                self.functionDefStmt()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 63
                self.functionCallStmt()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 64
                self.match(MyParser.LBRACE)
                self.state = 65
                self.stmtList()
                self.state = 66
                self.match(MyParser.RBRACE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclareStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(MyParser.TypeContext,0)


        def idList(self):
            return self.getTypedRuleContext(MyParser.IdListContext,0)


        def SEMICOLON(self):
            return self.getToken(MyParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return MyParser.RULE_declareStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclareStmt" ):
                listener.enterDeclareStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclareStmt" ):
                listener.exitDeclareStmt(self)




    def declareStmt(self):

        localctx = MyParser.DeclareStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_declareStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            self.type_()
            self.state = 71
            self.idList()
            self.state = 72
            self.match(MyParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEYWORD_INT(self):
            return self.getToken(MyParser.KEYWORD_INT, 0)

        def KEYWORD_DOUBLE(self):
            return self.getToken(MyParser.KEYWORD_DOUBLE, 0)

        def KEYWORD_BOOL(self):
            return self.getToken(MyParser.KEYWORD_BOOL, 0)

        def KEYWORD_CHAR(self):
            return self.getToken(MyParser.KEYWORD_CHAR, 0)

        def KEYWORD_LONG(self):
            return self.getToken(MyParser.KEYWORD_LONG, 0)

        def getRuleIndex(self):
            return MyParser.RULE_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterType" ):
                listener.enterType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitType" ):
                listener.exitType(self)




    def type_(self):

        localctx = MyParser.TypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 62) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.IDENTIFIER)
            else:
                return self.getToken(MyParser.IDENTIFIER, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.COMMA)
            else:
                return self.getToken(MyParser.COMMA, i)

        def getRuleIndex(self):
            return MyParser.RULE_idList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdList" ):
                listener.enterIdList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdList" ):
                listener.exitIdList(self)




    def idList(self):

        localctx = MyParser.IdListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_idList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 76
            self.match(MyParser.IDENTIFIER)
            self.state = 81
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 77
                self.match(MyParser.COMMA)
                self.state = 78
                self.match(MyParser.IDENTIFIER)
                self.state = 83
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(MyParser.IDENTIFIER, 0)

        def assignOp(self):
            return self.getTypedRuleContext(MyParser.AssignOpContext,0)


        def expression(self):
            return self.getTypedRuleContext(MyParser.ExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(MyParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return MyParser.RULE_assignStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignStmt" ):
                listener.enterAssignStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignStmt" ):
                listener.exitAssignStmt(self)




    def assignStmt(self):

        localctx = MyParser.AssignStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_assignStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 84
            self.match(MyParser.IDENTIFIER)
            self.state = 85
            self.assignOp()
            self.state = 86
            self.expression()
            self.state = 87
            self.match(MyParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ASSIGN(self):
            return self.getToken(MyParser.ASSIGN, 0)

        def PLUS_ASSIGN(self):
            return self.getToken(MyParser.PLUS_ASSIGN, 0)

        def MINUS_ASSIGN(self):
            return self.getToken(MyParser.MINUS_ASSIGN, 0)

        def MULT_ASSIGN(self):
            return self.getToken(MyParser.MULT_ASSIGN, 0)

        def DIV_ASSIGN(self):
            return self.getToken(MyParser.DIV_ASSIGN, 0)

        def getRuleIndex(self):
            return MyParser.RULE_assignOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignOp" ):
                listener.enterAssignOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignOp" ):
                listener.exitAssignOp(self)




    def assignOp(self):

        localctx = MyParser.AssignOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_assignOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 507904) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionDefStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEYWORD_FUN(self):
            return self.getToken(MyParser.KEYWORD_FUN, 0)

        def functionName(self):
            return self.getTypedRuleContext(MyParser.FunctionNameContext,0)


        def LPAREN(self):
            return self.getToken(MyParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(MyParser.RPAREN, 0)

        def ASSIGN(self):
            return self.getToken(MyParser.ASSIGN, 0)

        def expression(self):
            return self.getTypedRuleContext(MyParser.ExpressionContext,0)


        def SEMICOLON(self):
            return self.getToken(MyParser.SEMICOLON, 0)

        def paramList(self):
            return self.getTypedRuleContext(MyParser.ParamListContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_functionDefStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionDefStmt" ):
                listener.enterFunctionDefStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionDefStmt" ):
                listener.exitFunctionDefStmt(self)




    def functionDefStmt(self):

        localctx = MyParser.FunctionDefStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_functionDefStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 91
            self.match(MyParser.KEYWORD_FUN)
            self.state = 92
            self.functionName()
            self.state = 93
            self.match(MyParser.LPAREN)
            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 62) != 0):
                self.state = 94
                self.paramList()


            self.state = 97
            self.match(MyParser.RPAREN)
            self.state = 98
            self.match(MyParser.ASSIGN)
            self.state = 99
            self.expression()
            self.state = 100
            self.match(MyParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(MyParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return MyParser.RULE_functionName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionName" ):
                listener.enterFunctionName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionName" ):
                listener.exitFunctionName(self)




    def functionName(self):

        localctx = MyParser.FunctionNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_functionName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(MyParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.TypeContext)
            else:
                return self.getTypedRuleContext(MyParser.TypeContext,i)


        def IDENTIFIER(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.IDENTIFIER)
            else:
                return self.getToken(MyParser.IDENTIFIER, i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.COMMA)
            else:
                return self.getToken(MyParser.COMMA, i)

        def getRuleIndex(self):
            return MyParser.RULE_paramList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParamList" ):
                listener.enterParamList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParamList" ):
                listener.exitParamList(self)




    def paramList(self):

        localctx = MyParser.ParamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_paramList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 104
            self.type_()
            self.state = 105
            self.match(MyParser.IDENTIFIER)
            self.state = 112
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 106
                self.match(MyParser.COMMA)
                self.state = 107
                self.type_()
                self.state = 108
                self.match(MyParser.IDENTIFIER)
                self.state = 114
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def functionCall(self):
            return self.getTypedRuleContext(MyParser.FunctionCallContext,0)


        def SEMICOLON(self):
            return self.getToken(MyParser.SEMICOLON, 0)

        def getRuleIndex(self):
            return MyParser.RULE_functionCallStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCallStmt" ):
                listener.enterFunctionCallStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCallStmt" ):
                listener.exitFunctionCallStmt(self)




    def functionCallStmt(self):

        localctx = MyParser.FunctionCallStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_functionCallStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115
            self.functionCall()
            self.state = 116
            self.match(MyParser.SEMICOLON)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def functionName(self):
            return self.getTypedRuleContext(MyParser.FunctionNameContext,0)


        def LPAREN(self):
            return self.getToken(MyParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(MyParser.RPAREN, 0)

        def argList(self):
            return self.getTypedRuleContext(MyParser.ArgListContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_functionCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCall" ):
                listener.enterFunctionCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCall" ):
                listener.exitFunctionCall(self)




    def functionCall(self):

        localctx = MyParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_functionCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self.functionName()
            self.state = 119
            self.match(MyParser.LPAREN)
            self.state = 121
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1754495192192) != 0):
                self.state = 120
                self.argList()


            self.state = 123
            self.match(MyParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyParser.ExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.COMMA)
            else:
                return self.getToken(MyParser.COMMA, i)

        def getRuleIndex(self):
            return MyParser.RULE_argList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgList" ):
                listener.enterArgList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgList" ):
                listener.exitArgList(self)




    def argList(self):

        localctx = MyParser.ArgListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_argList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 125
            self.expression()
            self.state = 130
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 126
                self.match(MyParser.COMMA)
                self.state = 127
                self.expression()
                self.state = 132
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ifExpression(self):
            return self.getTypedRuleContext(MyParser.IfExpressionContext,0)


        def boolExpr(self):
            return self.getTypedRuleContext(MyParser.BoolExprContext,0)


        def arithmeticExpr(self):
            return self.getTypedRuleContext(MyParser.ArithmeticExprContext,0)


        def functionCall(self):
            return self.getTypedRuleContext(MyParser.FunctionCallContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = MyParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_expression)
        try:
            self.state = 137
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 133
                self.ifExpression()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 134
                self.boolExpr()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 135
                self.arithmeticExpr()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 136
                self.functionCall()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEYWORD_IF(self):
            return self.getToken(MyParser.KEYWORD_IF, 0)

        def boolExpr(self):
            return self.getTypedRuleContext(MyParser.BoolExprContext,0)


        def KEYWORD_THEN(self):
            return self.getToken(MyParser.KEYWORD_THEN, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(MyParser.ExpressionContext,i)


        def KEYWORD_ELSE(self):
            return self.getToken(MyParser.KEYWORD_ELSE, 0)

        def getRuleIndex(self):
            return MyParser.RULE_ifExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfExpression" ):
                listener.enterIfExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfExpression" ):
                listener.exitIfExpression(self)




    def ifExpression(self):

        localctx = MyParser.IfExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_ifExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self.match(MyParser.KEYWORD_IF)
            self.state = 140
            self.boolExpr()
            self.state = 141
            self.match(MyParser.KEYWORD_THEN)
            self.state = 142
            self.expression()
            self.state = 143
            self.match(MyParser.KEYWORD_ELSE)
            self.state = 144
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BoolExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def boolTerm(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.BoolTermContext)
            else:
                return self.getTypedRuleContext(MyParser.BoolTermContext,i)


        def KEYWORD_ORELSE(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.KEYWORD_ORELSE)
            else:
                return self.getToken(MyParser.KEYWORD_ORELSE, i)

        def getRuleIndex(self):
            return MyParser.RULE_boolExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolExpr" ):
                listener.enterBoolExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolExpr" ):
                listener.exitBoolExpr(self)




    def boolExpr(self):

        localctx = MyParser.BoolExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_boolExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self.boolTerm()
            self.state = 151
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==12:
                self.state = 147
                self.match(MyParser.KEYWORD_ORELSE)
                self.state = 148
                self.boolTerm()
                self.state = 153
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BoolTermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def boolFactor(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.BoolFactorContext)
            else:
                return self.getTypedRuleContext(MyParser.BoolFactorContext,i)


        def KEYWORD_ANDALSO(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.KEYWORD_ANDALSO)
            else:
                return self.getToken(MyParser.KEYWORD_ANDALSO, i)

        def getRuleIndex(self):
            return MyParser.RULE_boolTerm

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolTerm" ):
                listener.enterBoolTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolTerm" ):
                listener.exitBoolTerm(self)




    def boolTerm(self):

        localctx = MyParser.BoolTermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_boolTerm)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.boolFactor()
            self.state = 159
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==13:
                self.state = 155
                self.match(MyParser.KEYWORD_ANDALSO)
                self.state = 156
                self.boolFactor()
                self.state = 161
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BoolFactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def boolLiteral(self):
            return self.getTypedRuleContext(MyParser.BoolLiteralContext,0)


        def LPAREN(self):
            return self.getToken(MyParser.LPAREN, 0)

        def boolExpr(self):
            return self.getTypedRuleContext(MyParser.BoolExprContext,0)


        def RPAREN(self):
            return self.getToken(MyParser.RPAREN, 0)

        def comparison(self):
            return self.getTypedRuleContext(MyParser.ComparisonContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_boolFactor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolFactor" ):
                listener.enterBoolFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolFactor" ):
                listener.exitBoolFactor(self)




    def boolFactor(self):

        localctx = MyParser.BoolFactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_boolFactor)
        try:
            self.state = 168
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 162
                self.boolLiteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 163
                self.match(MyParser.LPAREN)
                self.state = 164
                self.boolExpr()
                self.state = 165
                self.match(MyParser.RPAREN)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 167
                self.comparison()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BoolLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KEYWORD_TRUE(self):
            return self.getToken(MyParser.KEYWORD_TRUE, 0)

        def KEYWORD_FALSE(self):
            return self.getToken(MyParser.KEYWORD_FALSE, 0)

        def getRuleIndex(self):
            return MyParser.RULE_boolLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolLiteral" ):
                listener.enterBoolLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolLiteral" ):
                listener.exitBoolLiteral(self)




    def boolLiteral(self):

        localctx = MyParser.BoolLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_boolLiteral)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            _la = self._input.LA(1)
            if not(_la==10 or _la==11):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def arithmeticExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.ArithmeticExprContext)
            else:
                return self.getTypedRuleContext(MyParser.ArithmeticExprContext,i)


        def compOp(self):
            return self.getTypedRuleContext(MyParser.CompOpContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_comparison

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparison" ):
                listener.enterComparison(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparison" ):
                listener.exitComparison(self)




    def comparison(self):

        localctx = MyParser.ComparisonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_comparison)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.arithmeticExpr()
            self.state = 173
            self.compOp()
            self.state = 174
            self.arithmeticExpr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompOpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EQ(self):
            return self.getToken(MyParser.EQ, 0)

        def GT(self):
            return self.getToken(MyParser.GT, 0)

        def LT(self):
            return self.getToken(MyParser.LT, 0)

        def getRuleIndex(self):
            return MyParser.RULE_compOp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompOp" ):
                listener.enterCompOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompOp" ):
                listener.exitCompOp(self)




    def compOp(self):

        localctx = MyParser.CompOpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_compOp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 117440512) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArithmeticExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.TermContext)
            else:
                return self.getTypedRuleContext(MyParser.TermContext,i)


        def PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.PLUS)
            else:
                return self.getToken(MyParser.PLUS, i)

        def MINUS(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.MINUS)
            else:
                return self.getToken(MyParser.MINUS, i)

        def getRuleIndex(self):
            return MyParser.RULE_arithmeticExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArithmeticExpr" ):
                listener.enterArithmeticExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArithmeticExpr" ):
                listener.exitArithmeticExpr(self)




    def arithmeticExpr(self):

        localctx = MyParser.ArithmeticExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_arithmeticExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 178
            self.term()
            self.state = 183
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==19 or _la==20:
                self.state = 179
                _la = self._input.LA(1)
                if not(_la==19 or _la==20):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 180
                self.term()
                self.state = 185
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MyParser.ValueContext)
            else:
                return self.getTypedRuleContext(MyParser.ValueContext,i)


        def MULT(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.MULT)
            else:
                return self.getToken(MyParser.MULT, i)

        def DIV(self, i:int=None):
            if i is None:
                return self.getTokens(MyParser.DIV)
            else:
                return self.getToken(MyParser.DIV, i)

        def getRuleIndex(self):
            return MyParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)




    def term(self):

        localctx = MyParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_term)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 186
            self.value()
            self.state = 191
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==21 or _la==22:
                self.state = 187
                _la = self._input.LA(1)
                if not(_la==21 or _la==22):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 188
                self.value()
                self.state = 193
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MINUS(self):
            return self.getToken(MyParser.MINUS, 0)

        def factor(self):
            return self.getTypedRuleContext(MyParser.FactorContext,0)


        def getRuleIndex(self):
            return MyParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)




    def value(self):

        localctx = MyParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_value)
        try:
            self.state = 197
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [20]:
                self.enterOuterAlt(localctx, 1)
                self.state = 194
                self.match(MyParser.MINUS)
                self.state = 195
                self.factor()
                pass
            elif token in [31, 35, 36, 39, 40]:
                self.enterOuterAlt(localctx, 2)
                self.state = 196
                self.factor()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(MyParser.LPAREN, 0)

        def arithmeticExpr(self):
            return self.getTypedRuleContext(MyParser.ArithmeticExprContext,0)


        def RPAREN(self):
            return self.getToken(MyParser.RPAREN, 0)

        def IDENTIFIER(self):
            return self.getToken(MyParser.IDENTIFIER, 0)

        def INTEGER_LITERAL(self):
            return self.getToken(MyParser.INTEGER_LITERAL, 0)

        def CHAR_LITERAL(self):
            return self.getToken(MyParser.CHAR_LITERAL, 0)

        def DOUBLE_LITERAL(self):
            return self.getToken(MyParser.DOUBLE_LITERAL, 0)

        def getRuleIndex(self):
            return MyParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)




    def factor(self):

        localctx = MyParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_factor)
        try:
            self.state = 207
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [31]:
                self.enterOuterAlt(localctx, 1)
                self.state = 199
                self.match(MyParser.LPAREN)
                self.state = 200
                self.arithmeticExpr()
                self.state = 201
                self.match(MyParser.RPAREN)
                pass
            elif token in [40]:
                self.enterOuterAlt(localctx, 2)
                self.state = 203
                self.match(MyParser.IDENTIFIER)
                pass
            elif token in [35]:
                self.enterOuterAlt(localctx, 3)
                self.state = 204
                self.match(MyParser.INTEGER_LITERAL)
                pass
            elif token in [39]:
                self.enterOuterAlt(localctx, 4)
                self.state = 205
                self.match(MyParser.CHAR_LITERAL)
                pass
            elif token in [36]:
                self.enterOuterAlt(localctx, 5)
                self.state = 206
                self.match(MyParser.DOUBLE_LITERAL)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





