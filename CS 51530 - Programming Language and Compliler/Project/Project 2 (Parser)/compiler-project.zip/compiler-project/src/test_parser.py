import sys
import os
from antlr4 import *
from antlr4.error.ErrorListener import ErrorListener
from antlr4.tree.Trees import Trees

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../output')))

from MyLexer import MyLexer
from MyParser import MyParser

class CustomErrorListener(ErrorListener):
    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        print(f" Syntax Error at line {line}, column {column}: {msg}")
        sys.exit(1)

# Generate a .dot file from a parse tree
def export_tree_to_dot(tree, ruleNames, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        f.write('digraph ParseTree {\n')
        _write_node(tree, ruleNames, f)
        f.write('}\n')

def _write_node(node, ruleNames, f, node_id=[0]):
    current_id = node_id[0]
    node_id[0] += 1

    label = Trees.getNodeText(node, ruleNames).replace('"', '\\"')
    f.write(f'  node{current_id} [label="{label}"];\n')

    for i in range(node.getChildCount()):
        child = node.getChild(i)
        child_id = node_id[0]
        _write_node(child, ruleNames, f, node_id)
        f.write(f'  node{current_id} -> node{child_id};\n')

def main():
    if len(sys.argv) < 2:
        print("Usage: python src/test_parser.py <input_file>")
        sys.exit(1)

    input_file = sys.argv[1]
    input_stream = FileStream(input_file, encoding='utf-8')

    lexer = MyLexer(input_stream)
    token_stream = CommonTokenStream(lexer)
    parser = MyParser(token_stream)
    parser.removeErrorListeners()
    parser.addErrorListener(CustomErrorListener())

    tree = parser.program()

    print("Parsing completed successfully.")
    print("\n Parse Tree (Text Format):")
    print(tree.toStringTree(recog=parser))

    dot_output = "parse_tree.dot"
    export_tree_to_dot(tree, parser.ruleNames, dot_output)
    print(f"\n DOT file saved as: {dot_output}")
    print(" View it here: https://dreampuf.github.io/GraphvizOnline")

if __name__ == "__main__":
    main()
