# ANTLR4 Parser Project (Project 2)

## Overview
This project implements a parser for a custom language using ANTLR4 with Python. It supports parsing arithmetic expressions, boolean logic, function declarations and calls, if-then-else constructs, and more. The parser was built in Visual Studio Code using ANTLR4 with the Python3 target.

## Folder Structure
```
compiler-project/
├── grammar/
│   ├── MyLexer.g4
│   ├── MyParser.g4
├── input/
│   ├── sample_input.txt
│   ├── valid_*.txt
│   ├── invalid_*.txt
├── output/
│   ├── MyLexer.py
│   ├── MyParser.py
│   └── __init__.py
├── src/
│   └── test_parser.py
├── parse_tree.dot
├── requirements.txt
```

## Setup Instructions

1. Install ANTLR:
   - Download ANTLR jar from the official site.
   - Save it in a known directory (e.g., `Downloads/ANTLR`).

2. Install Python dependencies:
```
pip install antlr4-python3-runtime
```

3. Generate Lexer and Parser:
```
java -jar ..\ANTLR\antlr-4.13.2-complete.jar -Dlanguage=Python3 -o output grammar/MyLexer.g4
java -jar ..\ANTLR\antlr-4.13.2-complete.jar -Dlanguage=Python3 -o output grammar/MyParser.g4
```

4. Run the parser:
```
python src/test_parser.py input/sample_input.txt
```

## Visualizing the Parse Tree
After parsing, a `parse_tree.dot` file is generated. Paste it into:

[Graphviz Online Viewer](https://dreampuf.github.io/GraphvizOnline)

## Sample Input Example

```
fun f(int a, int b) = a + b;
int x, y;
x = 10;
y = 20;
x += y;

bool flag;
flag = x == y;

z = if x > y then 1 else 0;

{
  double j;
  j = 5;
}
```
