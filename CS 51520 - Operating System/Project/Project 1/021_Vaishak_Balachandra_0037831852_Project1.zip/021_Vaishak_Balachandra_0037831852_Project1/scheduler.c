/*
 * Author: Vaishak Balachandra
 * Roll Number: 021
 * PUID: 0037831852
 * Course: CS51520
 * Due Date: 28 February, 2025
 * Description: 
 * ---- This program simulates a process scheduler handling real-time and interactive processes.
 * ---- It includes CPU, Disk, and TTY scheduling, tracks resource usage, and prints a summary.
 * Assumptions:
 * ---- TTY is assumed as pre-emptive in nature.
 * ---- All requests(CPU, Disk, TTY) are made at the Arrival Time of that process, using which the time calculatins are made!!
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Symbolic constants
#define MAX_PROCESSES 100
#define MAX_RESOURCES 500
#define MAX_LINE_LENGTH 100
#define INTERACTIVE 0
#define REAL_TIME 1

// Process states
#define READY 0
#define RUNNING 1
#define WAITING 2
#define COMPLETED 3

// Resource types
#define CPU_RES 0
#define DISK_RES 1
#define TTY_RES 2

// Structure to represent a resource request
typedef struct {
    int type;           // Resource type (CPU, DISK, TTY)
    int duration;       // Duration in milliseconds
    int remaining_time; // Remaining time for this resource
} ResourceRequest;

// Structure to represent a process
typedef struct {
    int id;                     // Process ID
    int class;                  // INTERACTIVE or REAL_TIME
    int arrival_time;           // Arrival time
    int deadline;               // Deadline for real-time processes
    int status;                 // Process status
    int num_resources;          // Number of resource requests
    int current_resource;       // Current resource being processed
    ResourceRequest resources[MAX_RESOURCES]; // Array of resource requests
    int completion_time;        // Time when process completes
    bool missed_deadline;       // Whether deadline was missed (for real-time)
} Process;

// Structure to track resource usage
typedef struct {
    bool is_busy;               // Whether resource is busy
    int process_id;             // ID of process using the resource
    int resource_index;         // Index of resource in process
    int remaining_time;         // Remaining time for this resource
} ResourceStatus;

// Globals
Process processes[MAX_PROCESSES];
int process_count = 0;
ResourceStatus cpu = {false, -1, -1, 0};
ResourceStatus disk = {false, -1, -1, 0};
ResourceStatus tty = {false, -1, -1, 0};
int current_time = 0;
int last_print_time = 0;

// Statistics
int completed_real_time = 0;
int completed_interactive = 0;
int missed_deadlines = 0;
int total_disk_accesses = 0;
int total_disk_time = 0;
int waiting_disk_time = 0;
int cpu_busy_time = 0;
int disk_busy_time = 0;
int tty_busy_time = 0;

// Function prototypes
void read_input();
void simulate();
void print_process_table();
void print_summary();
int get_next_interactive_process();
int get_next_real_time_process();
int get_next_disk_process();
int get_next_tty_process();
void update_process_status(int pid, int status);
void check_completed_processes();
void check_real_time_deadlines();
void handle_idle_time(int start_time, int end_time);

// Main function
int main() {
    read_input();
    simulate();
    print_summary();
    return 0;
}

// Read input file
void read_input() {
    char line[MAX_LINE_LENGTH];
    int current_process = -1;
    int deadline = -1;

    while (fgets(line, MAX_LINE_LENGTH, stdin) != NULL) {
        // Remove trailing newline
        line[strcspn(line, "\n")] = 0;
        
        // Skip empty lines
        if (strlen(line) == 0) {
            continue;
        }

        char resource_type[20];
        int value;

        if (sscanf(line, "%s %d", resource_type, &value) == 2) {
            if (strcmp(resource_type, "INTERACTIVE") == 0) {
                current_process = process_count++;
                processes[current_process].id = current_process;
                processes[current_process].class = INTERACTIVE;
                processes[current_process].arrival_time = value;
                processes[current_process].status = READY;
                processes[current_process].num_resources = 0;
                processes[current_process].current_resource = 0;
                processes[current_process].deadline = -1;
                processes[current_process].completion_time = -1;
                processes[current_process].missed_deadline = false;
            } else if (strcmp(resource_type, "REAL-TIME") == 0) {
                current_process = process_count++;
                processes[current_process].id = current_process;
                processes[current_process].class = REAL_TIME;
                processes[current_process].arrival_time = value;
                processes[current_process].status = READY;
                processes[current_process].num_resources = 0;
                processes[current_process].current_resource = 0;
                processes[current_process].deadline = -1;
                processes[current_process].completion_time = -1;
                processes[current_process].missed_deadline = false;
            } else if (strcmp(resource_type, "DEADLINE") == 0) {
                if (current_process >= 0 && processes[current_process].class == REAL_TIME) {
                    processes[current_process].deadline = value;
                }
            } else if (strcmp(resource_type, "CPU") == 0) {
                if (current_process >= 0) {
                    int index = processes[current_process].num_resources++;
                    processes[current_process].resources[index].type = CPU_RES;
                    processes[current_process].resources[index].duration = value;
                    processes[current_process].resources[index].remaining_time = value;
                }
            } else if (strcmp(resource_type, "DISK") == 0) {
                if (current_process >= 0) {
                    int index = processes[current_process].num_resources++;
                    processes[current_process].resources[index].type = DISK_RES;
                    processes[current_process].resources[index].duration = value;
                    processes[current_process].resources[index].remaining_time = value;
                }
            } else if (strcmp(resource_type, "TTY") == 0) {
                if (current_process >= 0) {
                    int index = processes[current_process].num_resources++;
                    processes[current_process].resources[index].type = TTY_RES;
                    processes[current_process].resources[index].duration = value;
                    processes[current_process].resources[index].remaining_time = value;
                }
            }
        }
    }
}

// Main simulation function
void simulate() {
    printf("Simulation started\n");
    printf("------------------\n\n");

    bool all_complete = false;

    // Find the first process arrival time
    int first_arrival = -1;
    for (int i = 0; i < process_count; i++) {
        if (first_arrival == -1 || processes[i].arrival_time < first_arrival) {
            first_arrival = processes[i].arrival_time;
        }
    }

    if (first_arrival > 0) {
        handle_idle_time(0, first_arrival);
        current_time = first_arrival;
    }

    print_process_table();

    while (!all_complete) {
        check_completed_processes();
        check_real_time_deadlines();

        // Handle CPU scheduling
        if (!cpu.is_busy) {
            int next_real_time = get_next_real_time_process();
            if (next_real_time != -1) {
                int resource_index = processes[next_real_time].current_resource;
                if (processes[next_real_time].resources[resource_index].type == CPU_RES) {
                    cpu.is_busy = true;
                    cpu.process_id = next_real_time;
                    cpu.resource_index = resource_index;
                    cpu.remaining_time = processes[next_real_time].resources[resource_index].remaining_time;
                    update_process_status(next_real_time, RUNNING);
                    printf("Time %d: Process P%d (REAL-TIME) starts using CPU\n", current_time, next_real_time);
                    print_process_table();
                }
            } else {
                int next_interactive = get_next_interactive_process();
                if (next_interactive != -1) {
                    int resource_index = processes[next_interactive].current_resource;
                    if (processes[next_interactive].resources[resource_index].type == CPU_RES) {
                        cpu.is_busy = true;
                        cpu.process_id = next_interactive;
                        cpu.resource_index = resource_index;
                        cpu.remaining_time = processes[next_interactive].resources[resource_index].remaining_time;
                        update_process_status(next_interactive, RUNNING);
                        printf("Time %d: Process P%d (INTERACTIVE) starts using CPU\n", current_time, next_interactive);
                        print_process_table();
                    }
                }
            }
        }

        // Handle DISK scheduling (now tracking waiting time correctly)
        if (!disk.is_busy) {
            int next_disk = get_next_disk_process();
            if (next_disk != -1) {
                int resource_index = processes[next_disk].current_resource;
                
                // Track waiting time for disk access
                int request_time = processes[next_disk].arrival_time;
                if (current_time > request_time) {
                    waiting_disk_time += (current_time - request_time);
                }

                // Start disk access
                disk.is_busy = true;
                disk.process_id = next_disk;
                disk.resource_index = resource_index;
                disk.remaining_time = processes[next_disk].resources[resource_index].remaining_time;
                total_disk_accesses++;
                total_disk_time += disk.remaining_time;

                printf("Time %d: Process P%d starts using DISK\n", current_time, next_disk);
                print_process_table();
            }
        }

        // Handle TTY scheduling (Non-Preemptive)
        if (!tty.is_busy) {
            int next_tty = get_next_tty_process();
            if (next_tty != -1) {
                int resource_index = processes[next_tty].current_resource;
                tty.is_busy = true;
                tty.process_id = next_tty;
                tty.resource_index = resource_index;
                tty.remaining_time = processes[next_tty].resources[resource_index].remaining_time;
                update_process_status(next_tty, RUNNING);
                printf("Time %d: Process P%d (%s) starts using TTY\n", current_time, next_tty, 
                       processes[next_tty].class == REAL_TIME ? "REAL-TIME" : "INTERACTIVE");
                print_process_table();
            }
        }

        // Determine the next event time
        int next_event_time = current_time + 1000; // Large default value

        for (int i = 0; i < process_count; i++) {
            if (processes[i].status == READY && processes[i].arrival_time > current_time &&
                processes[i].arrival_time < next_event_time) {
                next_event_time = processes[i].arrival_time;
            }
        }

        if (cpu.is_busy && current_time + cpu.remaining_time < next_event_time) {
            next_event_time = current_time + cpu.remaining_time;
        }

        if (disk.is_busy && current_time + disk.remaining_time < next_event_time) {
            next_event_time = current_time + disk.remaining_time;
        }

        if (tty.is_busy && current_time + tty.remaining_time < next_event_time) {
            next_event_time = current_time + tty.remaining_time;
        }

        // Ensure TTY gets its full processing time
        if (tty.is_busy && next_event_time < current_time + tty.remaining_time) {
            next_event_time = current_time + tty.remaining_time;
        }

        // Check if all processes are completed
        if (next_event_time == current_time + 1000) {
            all_complete = true;
            for (int i = 0; i < process_count; i++) {
                if (processes[i].status != COMPLETED) {
                    all_complete = false;
                    break;
                }
            }
            if (all_complete) {
                break;
            }
        }

        // Handle idle time reporting
        if (next_event_time > current_time && !cpu.is_busy && !disk.is_busy && !tty.is_busy) {
            handle_idle_time(current_time, next_event_time);
        }

        // Update resource usage times
        int time_diff = next_event_time - current_time;

        if (cpu.is_busy) {
            int decrement = (time_diff > cpu.remaining_time) ? cpu.remaining_time : time_diff;
            cpu.remaining_time -= decrement;
            cpu_busy_time += decrement;
        }

        if (disk.is_busy) {
            int decrement = (time_diff > disk.remaining_time) ? disk.remaining_time : time_diff;
            disk.remaining_time -= decrement;
            disk_busy_time += decrement;
        }

        if (tty.is_busy) {
            int decrement = (time_diff > tty.remaining_time) ? tty.remaining_time : time_diff;
            tty.remaining_time -= decrement;
            tty_busy_time += decrement;
        }

        current_time = next_event_time;
    }

    printf("\nSimulation completed at time %d\n", current_time);
    print_process_table();
}

// Print process table
void print_process_table() {
    printf("\nProcess Table at time %d:\n", current_time);
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("| PID | Class       | Arrival | Deadline | Status    | Resource List                                  |\n");
    printf("-------------------------------------------------------------------------------------------------------\n");

    for (int i = 0; i < process_count; i++) {
        char status_str[10];
        switch (processes[i].status) {
            case READY: strcpy(status_str, "READY"); break;
            case RUNNING: strcpy(status_str, "RUNNING"); break;
            case WAITING: strcpy(status_str, "WAITING"); break;
            case COMPLETED: strcpy(status_str, "COMPLETED"); break;
            default: strcpy(status_str, "UNKNOWN");
        }

        char resource_list[200] = "";  // Buffer to store formatted resource sequence

        for (int j = 0; j < processes[i].num_resources; j++) {
            char temp[30];
            int remaining_time = processes[i].resources[j].remaining_time;

            switch (processes[i].resources[j].type) {
                case CPU_RES:
                    sprintf(temp, "CPU: %d", remaining_time);
                    break;
                case DISK_RES:
                    sprintf(temp, "Disk: %d", remaining_time);
                    break;
                case TTY_RES:
                    sprintf(temp, "TTY: %d", remaining_time);
                    break;
                default:
                    sprintf(temp, "UNKNOWN");
            }

            if (j > 0) {
                strcat(resource_list, "; ");
            }
            strcat(resource_list, temp);
        }

        printf("| P%-2d | %-11s | %-7d | ", i, 
               processes[i].class == INTERACTIVE ? "INTERACTIVE" : "REAL-TIME",
               processes[i].arrival_time);

        if (processes[i].deadline == -1) {
            printf("%-8s | ", "N/A");
        } else {
            printf("%-8d | ", processes[i].deadline);
        }

        printf("%-9s | %-46s |\n", status_str, resource_list);
    }

    printf("-------------------------------------------------------------------------------------------------------\n");

    printf("CPU: %s", cpu.is_busy ? "BUSY (Process P" : "IDLE");
    if (cpu.is_busy) printf("%d)", cpu.process_id);
    printf("\n");

    printf("DISK: %s", disk.is_busy ? "BUSY (Process P" : "IDLE");
    if (disk.is_busy) printf("%d)", disk.process_id);
    printf("\n");

    printf("TTY: %s", tty.is_busy ? "BUSY (Process P" : "IDLE");
    if (tty.is_busy) printf("%d)", tty.process_id);
    printf("\n\n");

    last_print_time = current_time;
}

// Print summary report
void print_summary() {
    printf("\n-----------------------------------------\n");
    printf("SUMMARY REPORT\n");
    printf("-----------------------------------------\n");

    printf("a) Number of real-time processes completed: %d\n", completed_real_time);

    if (completed_real_time > 0) {
        printf("b) Percentage of real-time processes that missed deadline: %.2f%%\n",
               (float)missed_deadlines / completed_real_time * 100);
    } else {
        printf("b) Percentage of real-time processes that missed deadline: N/A\n");
    }

    printf("c) Number of interactive processes completed: %d\n", completed_interactive);
    printf("d) Total number of disk accesses: %d\n", total_disk_accesses);

    if (total_disk_accesses > 0) {
        printf("e) Average duration of disk access (including waiting time): %.2f ms\n",
               (float)(total_disk_time + waiting_disk_time) / total_disk_accesses);
    } else {
        printf("e) Average duration of disk access: N/A\n");
    }

    // Calculate total elapsed time from first process arrival to last process completion
    int first_process_time = -1;
    int last_process_completion = 0;

    for (int i = 0; i < process_count; i++) {
        if (first_process_time == -1 || processes[i].arrival_time < first_process_time) {
            first_process_time = processes[i].arrival_time;
        }
        if (processes[i].completion_time > last_process_completion) {
            last_process_completion = processes[i].completion_time;
        }
    }

    int total_time_elapsed = last_process_completion - first_process_time;

    printf("f) Total time elapsed: %d ms\n", total_time_elapsed);
    printf("g) CPU utilization: %d/%d = %.2f%%\n", cpu_busy_time, total_time_elapsed, (float)cpu_busy_time / total_time_elapsed * 100);
    printf("   Disk utilization: %d/%d = %.2f%%\n", disk_busy_time, total_time_elapsed, (float)disk_busy_time / total_time_elapsed * 100);
    printf("   TTY utilization: %d/%d = %.2f%%\n", tty_busy_time, total_time_elapsed, (float)tty_busy_time / total_time_elapsed * 100);
    
}

// Get the next interactive process to run on CPU
int get_next_interactive_process() {
    for (int i = 0; i < process_count; i++) {
        if (processes[i].class == INTERACTIVE && 
            processes[i].status == READY && 
            current_time >= processes[i].arrival_time &&
            processes[i].current_resource < processes[i].num_resources &&
            processes[i].resources[processes[i].current_resource].type == CPU_RES) {
            return i;
        }
    }
    return -1;
}

// Get the next real-time process to run on CPU
int get_next_real_time_process() {
    for (int i = 0; i < process_count; i++) {
        if (processes[i].class == REAL_TIME && 
            processes[i].status == READY && 
            current_time >= processes[i].arrival_time &&
            processes[i].current_resource < processes[i].num_resources &&
            processes[i].resources[processes[i].current_resource].type == CPU_RES) {
            return i;
        }
    }
    return -1;
}

// Get the next process that needs disk access (FCFS)
int get_next_disk_process() {
    int earliest_arrival = -1;
    int selected_process = -1;

    for (int i = 0; i < process_count; i++) {
        if (processes[i].status == READY &&
            current_time >= processes[i].arrival_time &&
            processes[i].current_resource < processes[i].num_resources &&
            processes[i].resources[processes[i].current_resource].type == DISK_RES) {
            
            if (earliest_arrival == -1 || processes[i].arrival_time < earliest_arrival) {
                earliest_arrival = processes[i].arrival_time;
                selected_process = i;
            }
        }
    }

    return selected_process;
}

// Get the next process that needs TTY access (prioritize real-time over interactive)
int get_next_tty_process() {
    // First check real-time processes
    for (int i = 0; i < process_count; i++) {
        if (processes[i].class == REAL_TIME && 
            processes[i].status == READY && 
            current_time >= processes[i].arrival_time &&
            processes[i].current_resource < processes[i].num_resources &&
            processes[i].resources[processes[i].current_resource].type == TTY_RES) {
            return i;
        }
    }
    
    // If no real-time process needs TTY, check interactive processes
    for (int i = 0; i < process_count; i++) {
        if (processes[i].class == INTERACTIVE && 
            processes[i].status == READY && 
            current_time >= processes[i].arrival_time &&
            processes[i].current_resource < processes[i].num_resources &&
            processes[i].resources[processes[i].current_resource].type == TTY_RES) {
            return i;
        }
    }
    
    return -1;
}

// Update process status
void update_process_status(int pid, int status) {
    if (pid >= 0 && pid < process_count) {
        processes[pid].status = status;
    }
}

// Check for completed processes and resources
void check_completed_processes() {
    // Check CPU completion
    if (cpu.is_busy && cpu.remaining_time <= 0) {
        int pid = cpu.process_id;

        // Mark the current CPU resource as completed
        processes[pid].resources[processes[pid].current_resource].remaining_time = 0;
        processes[pid].current_resource++;

        // Check if process has completed all resources
        if (processes[pid].current_resource >= processes[pid].num_resources) {
            update_process_status(pid, COMPLETED);
            processes[pid].completion_time = current_time;

            // Increment the completed count based on process type
            if (processes[pid].class == REAL_TIME) {
                completed_real_time++;
            } else {
                completed_interactive++;
            }

            printf("Time %d: Process P%d completed all resources\n", current_time, pid);
        } else {
            update_process_status(pid, READY);
            printf("Time %d: Process P%d completed CPU usage, moving to next resource\n", current_time, pid);
        }

        // Free the CPU
        cpu.is_busy = false;
        cpu.process_id = -1;
        print_process_table();
    }

    // Check DISK completion
    if (disk.is_busy && disk.remaining_time <= 0) {
        int pid = disk.process_id;

        // Mark the current DISK resource as completed
        processes[pid].resources[processes[pid].current_resource].remaining_time = 0;
        processes[pid].current_resource++;

        // Check if process has completed all resources
        if (processes[pid].current_resource >= processes[pid].num_resources) {
            update_process_status(pid, COMPLETED);
            processes[pid].completion_time = current_time;

            // Increment the completed count based on process type
            if (processes[pid].class == REAL_TIME) {
                completed_real_time++;
            } else {
                completed_interactive++;
            }

            printf("Time %d: Process P%d completed all resources\n", current_time, pid);
        } else {
            update_process_status(pid, READY);
            printf("Time %d: Process P%d completed DISK usage, moving to next resource\n", current_time, pid);
        }

        // Free the DISK
        disk.is_busy = false;
        disk.process_id = -1;
        print_process_table();
    }

    // Check TTY completion
    if (tty.is_busy && tty.remaining_time <= 0) {
        int pid = tty.process_id;

        // Mark the current TTY resource as completed
        processes[pid].resources[processes[pid].current_resource].remaining_time = 0;
        processes[pid].current_resource++;

        // Check if process has completed all resources
        if (processes[pid].current_resource >= processes[pid].num_resources) {
            update_process_status(pid, COMPLETED);
            processes[pid].completion_time = current_time;

            // Increment the completed count based on process type
            if (processes[pid].class == REAL_TIME) {
                completed_real_time++;
            } else {
                completed_interactive++;
            }

            printf("Time %d: Process P%d completed all resources\n", current_time, pid);
        } else {
            update_process_status(pid, READY);
            printf("Time %d: Process P%d completed TTY usage, moving to next resource\n", current_time, pid);
        }

        // Free the TTY
        tty.is_busy = false;
        tty.process_id = -1;
        print_process_table();
    }
}

// Check real-time processes for missed deadlines
void check_real_time_deadlines() {
    for (int i = 0; i < process_count; i++) {
        if (processes[i].class == REAL_TIME && 
            processes[i].status != COMPLETED && 
            processes[i].deadline != -1 && 
            current_time > processes[i].deadline && 
            !processes[i].missed_deadline) {
            
            processes[i].missed_deadline = true;
            printf("Time %d: Process P%d (REAL-TIME) missed its deadline of %d\n", 
                   current_time, i, processes[i].deadline);
        }
    }
}

// Handle idle time reporting
void handle_idle_time(int start_time, int end_time) {
    if (end_time > start_time) {
        printf("Time %d-%d: IDLE\n", start_time, end_time);
    }
}