# 🧠 Memory Management Simulator – Operating Systems Project

This project simulates a basic virtual memory management system, including **page tables**, a **Translation Lookaside Buffer (TLB)**, and **paging from a backing store**. It reads a list of virtual addresses, performs address translation, and outputs the corresponding physical addresses and values.

---

## 📁 Files Included

| File                | Description                                           |
|---------------------|-------------------------------------------------------|
| `memory_manager.c`  | Core implementation of the memory management system   |
| `addresses.txt`     | Input file containing virtual addresses               |
| `correct.txt`       | Expected correct output (for comparison)              |
| `BACKING_STORE.bin` | Simulated backing store containing memory pages       |
| `output.txt`        | Program output: translated addresses and stats        |

---

## 🛠️ How to Compile and Run

### ✅ Requirements
- C Compiler (e.g., `gcc`)
- Visual Studio Code or terminal
- `BACKING_STORE.bin` must be in the same directory

### 🧪 Steps to Run

1. **Open Terminal in Project Directory**  
   Example:  
   ```
   cd path/to/project
   ```

2. **Compile the Program**
   ```bash
   gcc a.c -o a
   ```

3. **Run with Input File**
   ```bash
   ./a addresses.txt
   ```

4. **Check Output**
   - The program writes results to `output.txt`.

5. **Compare with Correct Output (Optional)**
   **Windows PowerShell:**
   ```powershell
   $diff = Compare-Object (Get-Content output.txt) (Get-Content correct.txt)
   if ($diff.Count -eq 0) 
   {                                                           n
        Write-Host "`n✅ 100% Match: Your output.txt matches correct.txt perfectly!" -ForegroundColor Green
   } else 
   {                                                                                    d
        Write-Host "`n❌ Mismatch found between output.txt and correct.txt:" -ForegroundColor Red
        $diff
   }
   ```

---

## 🧠 Program Logic Overview

1. **Read Virtual Address** from `addresses.txt`
2. **Extract Page Number & Offset**
   - Page number = upper 8 bits
   - Offset = lower 8 bits
3. **TLB Lookup**
   - If hit → use cached frame
   - If miss → check page table
4. **Page Fault Handling**
   - Load page from `BACKING_STORE.bin` if not in memory
5. **Update TLB** using FIFO replacement
6. **Translate to Physical Address** and fetch value
7. **Output** translation and stats:
   - Total addresses translated
   - Page faults and page fault rate
   - TLB hits and TLB hit rate

---

## 📊 Sample Output (`output.txt`)
```
Virtual address: 16916 Physical address: 20 Value: 0
Virtual address: 62493 Physical address: 285 Value: 0
...
Number of Translated Addresses = 1000
Page Faults = 178
Page Fault Rate = 0.178
TLB Hits = 48
TLB Hit Rate = 0.048
```

---

## ✅ Features Implemented

- ✅ TLB with FIFO replacement policy (size = 16)
- ✅ Page table with 256 entries
- ✅ Paging from `BACKING_STORE.bin`
- ✅ Physical memory size = 256 frames (256 bytes/frame)
- ✅ Command-line argument support (`./a addresses.txt`)
- ✅ Full address translation logging to `output.txt`
- ✅ Final statistics reporting

---

## 📌 Notes

- `BACKING_STORE.bin` is required and must be in the same folder.
- All physical memory is initialized dynamically as needed.
- The output is fully deterministic and matches the provided `correct.txt`.

---

## 🙌 Author

**Vaishak Balachandra**  
Operating Systems — Memory Management Project  
Spring 2025
Roll No: 021
