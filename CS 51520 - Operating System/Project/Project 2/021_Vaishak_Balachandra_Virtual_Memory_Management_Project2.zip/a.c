#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TLB_SIZE 16
#define PAGE_TABLE_SIZE 256
#define FRAME_SIZE 256
#define PHYSICAL_MEMORY_SIZE 256

typedef struct {
    int page_number;
    int frame_number;
} TLBEntry;

TLBEntry tlb[TLB_SIZE];
int tlb_index = 0;

int page_table[PAGE_TABLE_SIZE];
signed char physical_memory[PHYSICAL_MEMORY_SIZE][FRAME_SIZE];
int next_free_frame = 0;

int page_faults = 0;
int tlb_hits = 0;

int search_tlb(int page_number) {
    for (int i = 0; i < TLB_SIZE; i++) {
        if (tlb[i].page_number == page_number) {
            return tlb[i].frame_number;
        }
    }
    return -1;
}

void add_to_tlb(int page_number, int frame_number) {
    tlb[tlb_index % TLB_SIZE].page_number = page_number;
    tlb[tlb_index % TLB_SIZE].frame_number = frame_number;
    tlb_index++;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <address file>\n", argv[0]);
        return 1;
    }

    FILE *address_file = fopen(argv[1], "r");
    FILE *backing_store = fopen("BACKING_STORE.bin", "rb");
    FILE *output_file = fopen("output.txt", "w");

    if (!address_file || !backing_store || !output_file) {
        printf("Error opening one of the required files.\n");
        return 1;
    }

    // Initialize page table
    for (int i = 0; i < PAGE_TABLE_SIZE; i++) {
        page_table[i] = -1;
    }

    int virtual_address;
    int translated_count = 0;

    while (fscanf(address_file, "%d", &virtual_address) != EOF) {
        int page_number = (virtual_address >> 8) & 0xFF;
        int offset = virtual_address & 0xFF;

        int frame_number = search_tlb(page_number);

        if (frame_number != -1) {
            tlb_hits++;
        } else {
            frame_number = page_table[page_number];
            if (frame_number == -1) {
                page_faults++;
                fseek(backing_store, page_number * FRAME_SIZE, SEEK_SET);
                fread(physical_memory[next_free_frame], sizeof(signed char), FRAME_SIZE, backing_store);
                frame_number = next_free_frame;
                page_table[page_number] = frame_number;
                next_free_frame++;
            }
            add_to_tlb(page_number, frame_number);
        }

        int physical_address = (frame_number << 8) | offset;
        signed char value = physical_memory[frame_number][offset];

        fprintf(output_file, "Virtual address: %d Physical address: %d Value: %d\n",
                virtual_address, physical_address, value);

        translated_count++;
    }

    // Append final stats to output file
    fprintf(output_file, "Number of Translated Addresses = %d\n", translated_count);
    fprintf(output_file, "Page Faults = %d\n", page_faults);
    fprintf(output_file, "Page Fault Rate = %.3f\n", (float)page_faults / translated_count);
    fprintf(output_file, "TLB Hits = %d\n", tlb_hits);
    fprintf(output_file, "TLB Hit Rate = %.3f\n", (float)tlb_hits / translated_count);

    fclose(address_file);
    fclose(backing_store);
    fclose(output_file);

    return 0;
}
